CREATE TABLE account_quota_cycles (
			id integer primary key autoincrement,
			activation_id integer not null,
			provider_cycle_key text not null,
			state text not null,
			scheduled_start_ms integer,
			scheduled_end_ms integer,
			actual_start_ms integer not null,
			actual_end_ms integer,
			duration_seconds integer,
			boundary_accuracy text not null,
			end_reason text,
			first_observation_id integer,
			last_observation_id integer,
			parent_cycle_id integer,
			created_at_ms integer not null,
			updated_at_ms integer not null,
			unique(activation_id, provider_cycle_key),
			foreign key(activation_id) references account_quota_window_activations(id),
			foreign key(first_observation_id) references account_quota_observations(id),
			foreign key(last_observation_id) references account_quota_observations(id),
			foreign key(parent_cycle_id) references account_quota_cycles(id)
		);
CREATE TABLE account_quota_observations (
			id integer primary key autoincrement,
			observation_hash text not null unique,
			account_key text not null,
			provider text not null,
			source text not null,
			source_observation_id text,
			inventory_scope_key text not null,
			inventory_mode text not null,
			observed_at_ms integer not null,
			window_count integer not null default 0,
			lifecycle_applied integer not null default 1,
			created_at_ms integer not null
		);
CREATE TABLE account_quota_snapshots (
			id integer primary key autoincrement,
			observation_id integer,
			logical_window_id integer,
			activation_id integer,
			cycle_id integer,
			account_key text not null,
			provider text not null,
			provider_window_id text not null,
			window_kind text not null,
			window_mode text not null,
			model_scope_kind text not null,
			model_scope_key text,
			model_ids_json text,
			scope_fingerprint text not null default '',
			content_hash text not null default '',
			source text not null,
			source_observation_id text,
			observed_at_ms integer not null,
			boundary_accuracy text not null,
			cycle_start_ms integer,
			cycle_end_ms integer,
			duration_seconds integer,
			used_percent real,
			remaining_percent real,
			used_value real,
			limit_value real,
			quota_unit text,
			reset_credits_available integer,
			reset_credits_json text,
			plan_type text,
			created_at_ms integer not null
		);
CREATE TABLE account_quota_window_activations (
			id integer primary key autoincrement,
			window_id integer not null,
			generation integer not null,
			status text not null,
			activated_at_ms integer not null,
			deactivated_at_ms integer,
			activation_accuracy text not null,
			deactivation_reason text,
			activate_observation_id integer,
			deactivate_observation_id integer,
			created_at_ms integer not null,
			updated_at_ms integer not null,
			unique(window_id, generation),
			foreign key(window_id) references account_quota_windows(id),
			foreign key(activate_observation_id) references account_quota_observations(id),
			foreign key(deactivate_observation_id) references account_quota_observations(id)
		);
CREATE TABLE account_quota_windows (
			id integer primary key autoincrement,
			account_key text not null,
			provider text not null,
			provider_window_id text not null,
			window_kind text not null,
			window_mode text not null,
			model_scope_kind text not null,
			model_scope_key text,
			model_ids_json text,
			scope_fingerprint text not null,
			inventory_scope_key text not null,
			relationship_kind text,
			container_provider_window_id text,
			availability text not null,
			generation integer not null default 1,
			absence_count integer not null default 0,
			first_seen_at_ms integer not null,
			last_seen_at_ms integer not null,
			missing_since_ms integer,
			deactivated_at_ms integer,
			last_observation_id integer,
			created_at_ms integer not null,
			updated_at_ms integer not null,
			unique(account_key, provider, provider_window_id, scope_fingerprint),
			foreign key(last_observation_id) references account_quota_observations(id)
		);
CREATE TABLE analytics_accounts (id TEXT PRIMARY KEY,provider TEXT NOT NULL,label TEXT NOT NULL,auth_index TEXT NOT NULL,auth_file TEXT NOT NULL,last_seen_ms INTEGER NOT NULL,poll_at_ms INTEGER NOT NULL DEFAULT 0,poll_error TEXT NOT NULL DEFAULT '');
INSERT INTO "analytics_accounts" (rowid,"id","provider","label","auth_index","auth_file","last_seen_ms","poll_at_ms","poll_error") VALUES(1,'a','claude','Main','','',1790812800000,0,'');
INSERT INTO "analytics_accounts" (rowid,"id","provider","label","auth_index","auth_file","last_seen_ms","poll_at_ms","poll_error") VALUES(2,'b','claude','Early reset','','',1790812800000,0,'');
INSERT INTO "analytics_accounts" (rowid,"id","provider","label","auth_index","auth_file","last_seen_ms","poll_at_ms","poll_error") VALUES(3,'c','claude','Ambiguous reset','','',1790812800000,0,'');
INSERT INTO "analytics_accounts" (rowid,"id","provider","label","auth_index","auth_file","last_seen_ms","poll_at_ms","poll_error") VALUES(4,'d','claude','H uncertainty','','',1790812800000,0,'');
INSERT INTO "analytics_accounts" (rowid,"id","provider","label","auth_index","auth_file","last_seen_ms","poll_at_ms","poll_error") VALUES(5,'gap','claude','No quota evidence','','',1790812800000,0,'');
CREATE TABLE analytics_credential_inventory (
 account TEXT PRIMARY KEY, checked_ms INTEGER NOT NULL, status TEXT NOT NULL
);
INSERT INTO "analytics_credential_inventory" (rowid,"account","checked_ms","status") VALUES(1,'a',1790812800000,'connected');
INSERT INTO "analytics_credential_inventory" (rowid,"account","checked_ms","status") VALUES(2,'b',1790812800000,'connected');
INSERT INTO "analytics_credential_inventory" (rowid,"account","checked_ms","status") VALUES(3,'c',1790812800000,'connected');
INSERT INTO "analytics_credential_inventory" (rowid,"account","checked_ms","status") VALUES(4,'d',1790812800000,'connected');
INSERT INTO "analytics_credential_inventory" (rowid,"account","checked_ms","status") VALUES(5,'gap',1790812800000,'connected');
CREATE TABLE analytics_event_keys (event_hash TEXT PRIMARY KEY,api_key_hash TEXT NOT NULL);
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(1,'known-mixed','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(2,'unknown-crossing','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(3,'enriched-mixed','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(4,'recorded-after-H','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(5,'early-before','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(6,'early-after','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(7,'ambiguous-unknown','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(8,'uncertain-H','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(9,'missing-price','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(10,'invalid-counters','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(11,'allocation-boundary','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(12,'request-12','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(13,'request-13','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(14,'request-14','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(15,'request-15','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(16,'request-16','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(17,'request-17','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(18,'request-18','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(19,'request-19','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(20,'request-20','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(21,'request-21','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(22,'request-22','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(23,'request-23','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(24,'request-24','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(25,'request-25','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(26,'request-26','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(27,'request-27','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(28,'request-28','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(29,'request-29','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(30,'request-30','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(31,'request-31','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(32,'request-32','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(33,'request-33','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(34,'request-34','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(35,'request-35','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(36,'request-36','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(37,'request-37','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(38,'request-38','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(39,'request-39','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(40,'request-40','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb');
INSERT INTO "analytics_event_keys" (rowid,"event_hash","api_key_hash") VALUES(41,'beyond-checkpoint','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
CREATE TABLE analytics_events (event_hash TEXT PRIMARY KEY,event_id INTEGER NOT NULL,account TEXT NOT NULL,started_ms INTEGER NOT NULL,completed_ms INTEGER NOT NULL,payload TEXT NOT NULL);
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(1,'known-mixed',1,'a',1790553602000,1790553602100,'{"source_token_details":{"cache_write_5m":250000,"cache_write_1h":750000},"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":1,"event_hash":"known-mixed","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553602000,"completed_at_ms":1790553602100,"recorded_at_ms":1790553602200,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(2,'unknown-crossing',2,'a',1790553603000,1790553603100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":2,"event_hash":"unknown-crossing","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553603000,"completed_at_ms":1790553603100,"recorded_at_ms":1790553603200,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(3,'enriched-mixed',3,'a',1790795800000,1790795800100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":3,"event_hash":"enriched-mixed","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790795800000,"completed_at_ms":1790795800100,"recorded_at_ms":1790795800200,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(4,'recorded-after-H',4,'a',1790796800000,1790796800100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":4,"event_hash":"recorded-after-H","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790796800000,"completed_at_ms":1790796800100,"recorded_at_ms":1790812800001,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(5,'early-before',5,'b',1790726380000,1790726380100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":5,"event_hash":"early-before","request_id":"","account":"b","provider":"claude","label":"b","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790726380000,"completed_at_ms":1790726380100,"recorded_at_ms":1790726380200,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(6,'early-after',6,'b',1790726400500,1790726400600,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":6,"event_hash":"early-after","request_id":"","account":"b","provider":"claude","label":"b","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790726400500,"completed_at_ms":1790726400600,"recorded_at_ms":1790726400700,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(7,'ambiguous-unknown',7,'c',1790726380000,1790726380100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":7,"event_hash":"ambiguous-unknown","request_id":"","account":"c","provider":"claude","label":"c","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790726380000,"completed_at_ms":1790726380100,"recorded_at_ms":1790726380200,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(8,'uncertain-H',8,'d',1790796800000,1790796800100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":8,"event_hash":"uncertain-H","request_id":"","account":"d","provider":"claude","label":"d","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790796800000,"completed_at_ms":1790796800100,"recorded_at_ms":1790796800200,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(9,'missing-price',9,'gap',1790726399000,1790726399100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":9,"event_hash":"missing-price","request_id":"","account":"gap","provider":"claude","label":"gap","auth_index":"","auth_file":"","model":"missing-model","requested_model":"","service_tier":"","started_at_ms":1790726399000,"completed_at_ms":1790726399100,"recorded_at_ms":1790726399200,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(10,'invalid-counters',10,'gap',1790726399000,1790726399100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":10,"event_hash":"invalid-counters","request_id":"","account":"gap","provider":"claude","label":"gap","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790726399000,"completed_at_ms":1790726399100,"recorded_at_ms":1790726399200,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":3},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(11,'allocation-boundary',11,'a',1790794800500,1790794801500,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":11,"event_hash":"allocation-boundary","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790794800500,"completed_at_ms":1790794801500,"recorded_at_ms":1790794800700,"header_time_ms":0,"tokens":{"input":1000000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000000,"total":1000000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(12,'request-12',12,'a',1790553610012,1790553610112,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":12,"event_hash":"request-12","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610012,"completed_at_ms":1790553610112,"recorded_at_ms":1790553610212,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(13,'request-13',13,'a',1790553610013,1790553610113,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":13,"event_hash":"request-13","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610013,"completed_at_ms":1790553610113,"recorded_at_ms":1790553610213,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(14,'request-14',14,'a',1790553610014,1790553610114,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":14,"event_hash":"request-14","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610014,"completed_at_ms":1790553610114,"recorded_at_ms":1790553610214,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(15,'request-15',15,'a',1790553610015,1790553610115,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":15,"event_hash":"request-15","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610015,"completed_at_ms":1790553610115,"recorded_at_ms":1790553610215,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(16,'request-16',16,'a',1790553610016,1790553610116,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":16,"event_hash":"request-16","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610016,"completed_at_ms":1790553610116,"recorded_at_ms":1790553610216,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(17,'request-17',17,'a',1790553610017,1790553610117,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":17,"event_hash":"request-17","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610017,"completed_at_ms":1790553610117,"recorded_at_ms":1790553610217,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(18,'request-18',18,'a',1790553610018,1790553610118,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":18,"event_hash":"request-18","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610018,"completed_at_ms":1790553610118,"recorded_at_ms":1790553610218,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(19,'request-19',19,'a',1790553610019,1790553610119,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":19,"event_hash":"request-19","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610019,"completed_at_ms":1790553610119,"recorded_at_ms":1790553610219,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(20,'request-20',20,'a',1790553610020,1790553610120,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":20,"event_hash":"request-20","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610020,"completed_at_ms":1790553610120,"recorded_at_ms":1790553610220,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(21,'request-21',21,'a',1790553610021,1790553610121,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":21,"event_hash":"request-21","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610021,"completed_at_ms":1790553610121,"recorded_at_ms":1790553610221,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(22,'request-22',22,'a',1790553610022,1790553610122,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":22,"event_hash":"request-22","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610022,"completed_at_ms":1790553610122,"recorded_at_ms":1790553610222,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(23,'request-23',23,'a',1790553610023,1790553610123,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":23,"event_hash":"request-23","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610023,"completed_at_ms":1790553610123,"recorded_at_ms":1790553610223,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(24,'request-24',24,'a',1790553610024,1790553610124,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":24,"event_hash":"request-24","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610024,"completed_at_ms":1790553610124,"recorded_at_ms":1790553610224,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(25,'request-25',25,'a',1790553610025,1790553610125,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":25,"event_hash":"request-25","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610025,"completed_at_ms":1790553610125,"recorded_at_ms":1790553610225,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(26,'request-26',26,'a',1790553610026,1790553610126,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":26,"event_hash":"request-26","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610026,"completed_at_ms":1790553610126,"recorded_at_ms":1790553610226,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(27,'request-27',27,'a',1790553610027,1790553610127,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":27,"event_hash":"request-27","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610027,"completed_at_ms":1790553610127,"recorded_at_ms":1790553610227,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(28,'request-28',28,'a',1790553610028,1790553610128,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":28,"event_hash":"request-28","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610028,"completed_at_ms":1790553610128,"recorded_at_ms":1790553610228,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(29,'request-29',29,'a',1790553610029,1790553610129,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":29,"event_hash":"request-29","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610029,"completed_at_ms":1790553610129,"recorded_at_ms":1790553610229,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(30,'request-30',30,'a',1790553610030,1790553610130,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":30,"event_hash":"request-30","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610030,"completed_at_ms":1790553610130,"recorded_at_ms":1790553610230,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(31,'request-31',31,'a',1790553610031,1790553610131,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":31,"event_hash":"request-31","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610031,"completed_at_ms":1790553610131,"recorded_at_ms":1790553610231,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(32,'request-32',32,'a',1790553610032,1790553610132,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":32,"event_hash":"request-32","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610032,"completed_at_ms":1790553610132,"recorded_at_ms":1790553610232,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(33,'request-33',33,'a',1790553610033,1790553610133,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":33,"event_hash":"request-33","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610033,"completed_at_ms":1790553610133,"recorded_at_ms":1790553610233,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(34,'request-34',34,'a',1790553610034,1790553610134,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":34,"event_hash":"request-34","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610034,"completed_at_ms":1790553610134,"recorded_at_ms":1790553610234,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(35,'request-35',35,'a',1790553610035,1790553610135,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":35,"event_hash":"request-35","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610035,"completed_at_ms":1790553610135,"recorded_at_ms":1790553610235,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(36,'request-36',36,'a',1790553610036,1790553610136,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":36,"event_hash":"request-36","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610036,"completed_at_ms":1790553610136,"recorded_at_ms":1790553610236,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(37,'request-37',37,'a',1790553610037,1790553610137,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":37,"event_hash":"request-37","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610037,"completed_at_ms":1790553610137,"recorded_at_ms":1790553610237,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(38,'request-38',38,'a',1790553610038,1790553610138,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":38,"event_hash":"request-38","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610038,"completed_at_ms":1790553610138,"recorded_at_ms":1790553610238,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(39,'request-39',39,'a',1790553610039,1790553610139,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":39,"event_hash":"request-39","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610039,"completed_at_ms":1790553610139,"recorded_at_ms":1790553610239,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(40,'request-40',40,'a',1790553610040,1790553610140,'{"api_key_hash":"bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb","accounting_version":2,"id":40,"event_hash":"request-40","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553610040,"completed_at_ms":1790553610140,"recorded_at_ms":1790553610240,"header_time_ms":0,"tokens":{"input":1000,"output":0,"reasoning":0,"cached":0,"cache_creation":1000,"total":1000},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":5000000,"price_id":"captured","token_quality":"complete"}');
INSERT INTO "analytics_events" (rowid,"event_hash","event_id","account","started_ms","completed_ms","payload") VALUES(41,'beyond-checkpoint',100,'a',1790553605000,1790553605100,'{"api_key_hash":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","accounting_version":2,"id":100,"event_hash":"beyond-checkpoint","request_id":"","account":"a","provider":"claude","label":"a","auth_index":"","auth_file":"","model":"claude-opus-5-5","requested_model":"","service_tier":"","started_at_ms":1790553605000,"completed_at_ms":1790553605100,"recorded_at_ms":1790553605200,"header_time_ms":0,"tokens":{"input":999999999,"output":0,"reasoning":0,"cached":0,"cache_creation":999999999,"total":999999999},"raw_input_tokens":0,"failed":false,"streaming":false,"cost_nano_usd":4999999995000,"price_id":"captured","token_quality":"complete"}');
CREATE TABLE analytics_forecast_results (id TEXT PRIMARY KEY,forecast_id TEXT NOT NULL,settled_ms INTEGER NOT NULL,state TEXT NOT NULL,payload TEXT NOT NULL);
CREATE TABLE analytics_forecast_work (account TEXT PRIMARY KEY,generation INTEGER NOT NULL,next_ms INTEGER NOT NULL,after_forecast INTEGER NOT NULL DEFAULT 0,waiting INTEGER NOT NULL DEFAULT 0);
CREATE TABLE analytics_forecasts (id TEXT PRIMARY KEY,account TEXT NOT NULL,window_id TEXT NOT NULL,issued_ms INTEGER NOT NULL,reset_ms INTEGER NOT NULL,payload TEXT NOT NULL);
CREATE TABLE analytics_historical_valuations (id TEXT PRIMARY KEY,payload TEXT NOT NULL);
INSERT INTO "analytics_historical_valuations" (rowid,"id","payload") VALUES(1,'historical-5m-v1:57637878a37aa80ea25725239ddb94ac','{"id":"historical-5m-v1:57637878a37aa80ea25725239ddb94ac","source_checkpoint":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","events_through":40,"observations_through":18,"h_ms":1790812800000,"cutoff_ms":1790726400000,"timezone":"UTC","user_wording":"Whole historical windows completed after September 29, 2026, including crossing weeks","completion_rule":"whole canonical completed window; actual early reset; inclusive [cutoff,H]; source checkpoint bounded","windows":{"a-h":{"window_id":"a-h","end_ms":1790812800000,"earliest_ms":1790812800000,"latest_ms":1790812800000,"status":"closed","source":"retained_provider_reset"},"a-week":{"window_id":"a-week","end_ms":1790769600000,"earliest_ms":1790769600000,"latest_ms":1790769600000,"status":"closed","source":"retained_provider_reset"},"b-early":{"window_id":"b-early","end_ms":1790726400000,"earliest_ms":1790726400000,"latest_ms":1790726400000,"status":"closed","observation_id":"b-closure","source":"fixture:canonical-cycle"}}}');
CREATE TABLE analytics_normalization_rules (
 id TEXT PRIMARY KEY, captured_ms INTEGER NOT NULL, payload TEXT NOT NULL
);
INSERT INTO "analytics_normalization_rules" (rowid,"id","captured_ms","payload") VALUES(1,'profile-api-value-v3:6b9634cb3d78505292b2252f37fe2297',1790812800000,'{"historical":{"id":"historical-5m-v1:57637878a37aa80ea25725239ddb94ac","source_checkpoint":"cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc","events_through":40,"observations_through":18,"h_ms":1790812800000,"cutoff_ms":1790726400000,"timezone":"UTC","user_wording":"Whole historical windows completed after September 29, 2026, including crossing weeks","completion_rule":"whole canonical completed window; actual early reset; inclusive [cutoff,H]; source checkpoint bounded","windows":{"a-h":{"window_id":"a-h","end_ms":1790812800000,"earliest_ms":1790812800000,"latest_ms":1790812800000,"status":"closed","source":"retained_provider_reset"},"a-week":{"window_id":"a-week","end_ms":1790769600000,"earliest_ms":1790769600000,"latest_ms":1790769600000,"status":"closed","source":"retained_provider_reset"},"b-early":{"window_id":"b-early","end_ms":1790726400000,"earliest_ms":1790726400000,"latest_ms":1790726400000,"status":"closed","observation_id":"b-closure","source":"fixture:canonical-cycle"}}},"write_rate_source":"anthropic-write-multipliers-2026-09-29: 5m=1.25*model-context-service-tier-input; 1h=2*model-context-service-tier-input; https://platform.claude.com/docs/en/about-claude/pricing","id":"profile-api-value-v3:6b9634cb3d78505292b2252f37fe2297","policy":"profile-api-value-v3","captured_ms":1790812800000,"prices":{"claude-opus-5-5":{"prompt":4,"completion":20,"cache":0,"cacheRead":0.4,"cacheCreation":5,"promptConfigured":true,"completionConfigured":true,"cacheReadConfigured":true,"cacheCreationConfigured":true,"source":"synthetic fixture","updatedAtMs":1790726400000}},"references":{"antigravity":{"model":"gemini-3.8-flash","name":"Gemini 3.8 Flash","input_usd_per_million":0.75,"source":"https://ai.google.dev/gemini-api/docs/pricing"},"claude":{"model":"claude-opus-5-5","name":"Opus 5.5","input_usd_per_million":4,"source":"https://platform.claude.com/docs/en/about-claude/pricing"},"codex":{"model":"gpt-5.6-sol","name":"GPT-5.6 Sol","input_usd_per_million":4,"source":"https://developers.openai.com/api/docs/pricing"}}}');
INSERT INTO "analytics_normalization_rules" (rowid,"id","captured_ms","payload") VALUES(2,'profile-api-value-v2:0f84a9f1acce8ba3a13ab5034c05476a',1790467200000,'{"id":"profile-api-value-v2:0f84a9f1acce8ba3a13ab5034c05476a","policy":"profile-api-value-v2","captured_ms":1790467200000,"prices":{"claude-opus-5-5":{"prompt":4,"completion":20,"cache":0,"cacheRead":0.4,"cacheCreation":5,"promptConfigured":true,"completionConfigured":true,"cacheReadConfigured":true,"cacheCreationConfigured":true,"source":"synthetic fixture","updatedAtMs":1790726400000}},"references":{"antigravity":{"model":"gemini-3.8-flash","name":"Gemini 3.8 Flash","input_usd_per_million":0.75,"source":"https://ai.google.dev/gemini-api/docs/pricing"},"claude":{"model":"claude-opus-5-5","name":"Opus 5.5","input_usd_per_million":4,"source":"https://platform.claude.com/docs/en/about-claude/pricing"},"codex":{"model":"gpt-5.6-sol","name":"GPT-5.6 Sol","input_usd_per_million":4,"source":"https://developers.openai.com/api/docs/pricing"}}}');
CREATE TABLE analytics_observations (id TEXT PRIMARY KEY,account TEXT NOT NULL,observed_ms INTEGER NOT NULL,window_id TEXT NOT NULL,payload TEXT NOT NULL);
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(1,'a-week-open','a',1790208001000,'a-week','{"time_low_ms":1790208001000,"time_high_ms":1790208001000,"time_source":"provider","id":"a-week-open","account":"a","provider":"claude","kind":"weekly","scope":"all","start_ms":1790208000000,"reset_ms":1790769600000,"duration_ms":561600000,"used_percent":10,"observed_at_ms":1790208001000,"received_at_ms":1790208001000,"source":"provider_api","evidence":{"used_percent":10},"boundary":"explicit","window_id":"a-week"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(2,'a-week-last','a',1790769599000,'a-week','{"time_low_ms":1790769599000,"time_high_ms":1790769599000,"time_source":"provider","id":"a-week-last","account":"a","provider":"claude","kind":"weekly","scope":"all","start_ms":1790208000000,"reset_ms":1790769600000,"duration_ms":561600000,"used_percent":60,"observed_at_ms":1790769599000,"received_at_ms":1790769599000,"source":"provider_api","evidence":{"used_percent":60},"boundary":"explicit","window_id":"a-week"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(3,'a-old-open','a',1790553601000,'a-old','{"time_low_ms":1790553601000,"time_high_ms":1790553601000,"time_source":"provider","id":"a-old-open","account":"a","provider":"claude","kind":"5h","scope":"all","start_ms":1790553600000,"reset_ms":1790571600000,"duration_ms":18000000,"used_percent":5,"observed_at_ms":1790553601000,"received_at_ms":1790553601000,"source":"provider_api","evidence":{"used_percent":5},"boundary":"explicit","window_id":"a-old"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(4,'a-old-last','a',1790571599000,'a-old','{"time_low_ms":1790571599000,"time_high_ms":1790571599000,"time_source":"provider","id":"a-old-last","account":"a","provider":"claude","kind":"5h","scope":"all","start_ms":1790553600000,"reset_ms":1790571600000,"duration_ms":18000000,"used_percent":20,"observed_at_ms":1790571599000,"received_at_ms":1790571599000,"source":"provider_api","evidence":{"used_percent":20},"boundary":"explicit","window_id":"a-old"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(5,'a-h-open','a',1790794801000,'a-h','{"time_low_ms":1790794801000,"time_high_ms":1790794801000,"time_source":"provider","id":"a-h-open","account":"a","provider":"claude","kind":"5h","scope":"all","start_ms":1790794800000,"reset_ms":1790812800000,"duration_ms":18000000,"used_percent":1,"observed_at_ms":1790794801000,"received_at_ms":1790794801000,"source":"provider_api","evidence":{"used_percent":1},"boundary":"explicit","window_id":"a-h"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(6,'a-h-last','a',1790812799000,'a-h','{"time_low_ms":1790812799000,"time_high_ms":1790812799000,"time_source":"provider","id":"a-h-last","account":"a","provider":"claude","kind":"5h","scope":"all","start_ms":1790794800000,"reset_ms":1790812800000,"duration_ms":18000000,"used_percent":50,"observed_at_ms":1790812799000,"received_at_ms":1790812799000,"source":"provider_api","evidence":{"used_percent":50},"boundary":"explicit","window_id":"a-h"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(7,'a-current','a',1790812800000,'a-current','{"time_low_ms":1790812800000,"time_high_ms":1790812800000,"time_source":"provider","id":"a-current","account":"a","provider":"claude","kind":"5h","scope":"all","start_ms":1790812800000,"reset_ms":1790830800000,"duration_ms":18000000,"used_percent":2,"observed_at_ms":1790812800000,"received_at_ms":1790812800000,"source":"provider_api","evidence":{"used_percent":2},"boundary":"explicit","window_id":"a-current"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(8,'b-open','b',1790380800000,'b-early','{"time_low_ms":1790380800000,"time_high_ms":1790380800000,"time_source":"provider","id":"b-open","account":"b","provider":"claude","kind":"weekly","scope":"all","start_ms":1790294400000,"reset_ms":1790899200000,"duration_ms":604800000,"used_percent":10,"observed_at_ms":1790380800000,"received_at_ms":1790380800000,"source":"provider_api","evidence":{"used_percent":10},"boundary":"explicit","window_id":"b-early"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(9,'b-last','b',1790726390000,'b-early','{"time_low_ms":1790726390000,"time_high_ms":1790726390000,"time_source":"provider","id":"b-last","account":"b","provider":"claude","kind":"weekly","scope":"all","start_ms":1790294400000,"reset_ms":1790899200000,"duration_ms":604800000,"used_percent":80,"observed_at_ms":1790726390000,"received_at_ms":1790726390000,"source":"provider_api","evidence":{"used_percent":80},"boundary":"explicit","window_id":"b-early"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(10,'b-next','b',1790726405000,'b-current','{"time_low_ms":1790726405000,"time_high_ms":1790726405000,"time_source":"provider","id":"b-next","account":"b","provider":"claude","kind":"weekly","scope":"all","start_ms":1790726401000,"reset_ms":1791331201000,"duration_ms":604800000,"used_percent":1,"observed_at_ms":1790726405000,"received_at_ms":1790726405000,"source":"provider_api","evidence":{"used_percent":1},"boundary":"explicit","window_id":"b-current"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(11,'b-closure','b',1790726405000,'b-early','{"closed_cycle":{"window_id":"b-early","end_ms":1790726400000,"earliest_ms":1790726400000,"latest_ms":1790726400000,"status":"closed"},"id":"b-closure","account":"b","provider":"claude","kind":"weekly","scope":"all","start_ms":0,"reset_ms":0,"duration_ms":0,"used_percent":null,"observed_at_ms":1790726405000,"received_at_ms":1790726405000,"source":"fixture:canonical-cycle","evidence":null,"boundary":"","window_id":"b-early"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(12,'c-open','c',1790380800000,'c-early','{"time_low_ms":1790380800000,"time_high_ms":1790380800000,"time_source":"provider","id":"c-open","account":"c","provider":"claude","kind":"weekly","scope":"all","start_ms":1790294400000,"reset_ms":1790899200000,"duration_ms":604800000,"used_percent":10,"observed_at_ms":1790380800000,"received_at_ms":1790380800000,"source":"provider_api","evidence":{"used_percent":10},"boundary":"explicit","window_id":"c-early"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(13,'c-last','c',1790726390000,'c-early','{"time_low_ms":1790726390000,"time_high_ms":1790726390000,"time_source":"provider","id":"c-last","account":"c","provider":"claude","kind":"weekly","scope":"all","start_ms":1790294400000,"reset_ms":1790899200000,"duration_ms":604800000,"used_percent":80,"observed_at_ms":1790726390000,"received_at_ms":1790726390000,"source":"provider_api","evidence":{"used_percent":80},"boundary":"explicit","window_id":"c-early"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(14,'c-next','c',1790726405000,'c-current','{"time_low_ms":1790726405000,"time_high_ms":1790726405000,"time_source":"provider","id":"c-next","account":"c","provider":"claude","kind":"weekly","scope":"all","start_ms":1790726401000,"reset_ms":1791331201000,"duration_ms":604800000,"used_percent":1,"observed_at_ms":1790726405000,"received_at_ms":1790726405000,"source":"provider_api","evidence":{"used_percent":1},"boundary":"explicit","window_id":"c-current"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(15,'c-closure','c',1790726405000,'c-early','{"closed_cycle":{"window_id":"c-early","end_ms":1790726400000,"earliest_ms":1790726400000,"latest_ms":1790726400000,"status":"closed"},"id":"c-closure","account":"c","provider":"claude","kind":"weekly","scope":"all","start_ms":0,"reset_ms":0,"duration_ms":0,"used_percent":null,"observed_at_ms":1790726405000,"received_at_ms":1790726405000,"source":"fixture:canonical-cycle","evidence":null,"boundary":"","window_id":"c-early"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(16,'c-conflict','c',1790726405000,'c-early','{"closed_cycle":{"window_id":"c-early","end_ms":1790726400001,"earliest_ms":1790726400000,"latest_ms":1790726400001,"status":"closed"},"id":"c-conflict","account":"c","provider":"claude","kind":"weekly","scope":"all","start_ms":0,"reset_ms":0,"duration_ms":0,"used_percent":null,"observed_at_ms":1790726405000,"received_at_ms":1790726405000,"source":"fixture:canonical-cycle","evidence":null,"boundary":"","window_id":"c-early"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(17,'d-open','d',1790794801000,'d-h-band','{"time_low_ms":1790794801000,"time_high_ms":1790794801000,"time_source":"provider","id":"d-open","account":"d","provider":"claude","kind":"5h","scope":"all","start_ms":1790794800000,"reset_ms":1790812799500,"duration_ms":17999500,"used_percent":10,"observed_at_ms":1790794801000,"received_at_ms":1790794801000,"source":"provider_api","evidence":{"used_percent":10},"boundary":"explicit","window_id":"d-h-band"}');
INSERT INTO "analytics_observations" (rowid,"id","account","observed_ms","window_id","payload") VALUES(18,'d-last','d',1790812798000,'d-h-band','{"time_low_ms":1790812798000,"time_high_ms":1790812798000,"time_source":"provider","id":"d-last","account":"d","provider":"claude","kind":"5h","scope":"all","start_ms":1790794800000,"reset_ms":1790812800500,"duration_ms":18000500,"used_percent":50,"observed_at_ms":1790812798000,"received_at_ms":1790812798000,"source":"provider_api","evidence":{"used_percent":50},"boundary":"explicit","window_id":"d-h-band"}');
CREATE TABLE analytics_poll_runs (id INTEGER PRIMARY KEY AUTOINCREMENT,account TEXT NOT NULL,observed_ms INTEGER NOT NULL,source TEXT NOT NULL,status TEXT NOT NULL);
CREATE TABLE analytics_prices (id TEXT PRIMARY KEY,model TEXT NOT NULL,captured_at_ms INTEGER NOT NULL,payload TEXT NOT NULL);
INSERT INTO "analytics_prices" (rowid,"id","model","captured_at_ms","payload") VALUES(1,'captured','claude-opus-5-5',1790726400000,'{"price":{"prompt":4,"completion":20,"cache":0,"cacheRead":0.4,"cacheCreation":5,"promptConfigured":true,"completionConfigured":true,"cacheReadConfigured":true,"cacheCreationConfigured":true,"source":"synthetic fixture"},"source":"synthetic fixture"}');
CREATE TABLE analytics_profile_revisions (
 revision INTEGER PRIMARY KEY, created_ms INTEGER NOT NULL, action TEXT NOT NULL, payload TEXT NOT NULL
);
INSERT INTO "analytics_profile_revisions" (rowid,"revision","created_ms","action","payload") VALUES(0,0,0,'initial','{"revision":0,"profiles":[],"bindings":[]}');
INSERT INTO "analytics_profile_revisions" (rowid,"revision","created_ms","action","payload") VALUES(7,7,1790467200000,'fixture','{"revision":7,"profiles":[{"memberships":[{"account":"a","start_ms":0,"end_ms":0}],"id":"main","name":"=Main subscription","provider":"claude","archived":false,"active_account":"","created_ms":0},{"memberships":[{"account":"a","start_ms":1790553600000,"end_ms":1790726401000}],"id":"partial","name":"Dated membership","provider":"claude","archived":false,"active_account":"","created_ms":0},{"memberships":[{"account":"b","start_ms":0,"end_ms":0}],"id":"early","name":"Early reset","provider":"claude","archived":false,"active_account":"","created_ms":0},{"memberships":[{"account":"c","start_ms":0,"end_ms":0},{"account":"d","start_ms":0,"end_ms":0}],"id":"ambiguous","name":"Ambiguous","provider":"claude","archived":false,"active_account":"","created_ms":0},{"memberships":[{"account":"gap","start_ms":0,"end_ms":0}],"id":"gap","name":"Ledger without quota","provider":"claude","archived":false,"active_account":"","created_ms":0}],"bindings":[]}');
CREATE TABLE analytics_state (name TEXT PRIMARY KEY,value INTEGER NOT NULL);
INSERT INTO "analytics_state" (rowid,"name","value") VALUES(1,'forecast_activated_ms',0);
INSERT INTO "analytics_state" (rowid,"name","value") VALUES(2,'events',100);
INSERT INTO "analytics_state" (rowid,"name","value") VALUES(3,'event_keys',0);
INSERT INTO "analytics_state" (rowid,"name","value") VALUES(4,'historical_valuation',1);
CREATE TABLE analytics_token_evidence (revision INTEGER PRIMARY KEY AUTOINCREMENT,event_hash TEXT NOT NULL,source_id TEXT NOT NULL,payload TEXT NOT NULL,UNIQUE(event_hash,source_id));
INSERT INTO "analytics_token_evidence" (rowid,"revision","event_hash","source_id","payload") VALUES(1,1,'enriched-mixed','provider:late-split','{"cache_write_5m":250000,"cache_write_1h":500000}');
CREATE TABLE api_key_alias_history (
			api_key_hash text primary key,
			current_hash text not null
		);
INSERT INTO "api_key_alias_history" (rowid,"api_key_hash","current_hash") VALUES(1,'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
CREATE TABLE api_key_aliases (
			api_key_hash text primary key,
			alias text not null,
			updated_at_ms integer not null
		);
INSERT INTO "api_key_aliases" (rowid,"api_key_hash","alias","updated_at_ms") VALUES(1,'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','Work',1790726400000);
CREATE TABLE model_price_context_tiers (
			model text not null,
			threshold_tokens integer not null,
			prompt_per_1m real not null default 0,
			completion_per_1m real not null default 0,
			cache_per_1m real not null default 0,
			cache_read_per_1m real not null default 0,
			cache_creation_per_1m real not null default 0,
			prompt_configured integer not null default 0,
			completion_configured integer not null default 0,
			cache_configured integer not null default 0,
			cache_read_configured integer not null default 0,
			cache_creation_configured integer not null default 0,
			primary key (model, threshold_tokens),
			foreign key (model) references model_prices(model) on delete cascade
		);
CREATE TABLE model_price_service_tiers (
			model text not null,
			mode text not null,
			service_tier text not null,
			prompt_per_1m real not null default 0,
			completion_per_1m real not null default 0,
			cache_per_1m real not null default 0,
			cache_read_per_1m real not null default 0,
			cache_creation_per_1m real not null default 0,
			prompt_configured integer not null default 0,
			completion_configured integer not null default 0,
			cache_configured integer not null default 0,
			cache_read_configured integer not null default 0,
			cache_creation_configured integer not null default 0,
			primary key (model, mode, service_tier),
			foreign key (model) references model_prices(model) on delete cascade
		);
CREATE TABLE model_prices (
			model text primary key,
			prompt_per_1m real not null,
			completion_per_1m real not null,
			cache_per_1m real not null,
			cache_read_per_1m real not null default 0,
			cache_creation_per_1m real not null default 0,
			prompt_configured integer not null default 0,
			completion_configured integer not null default 0,
			cache_read_configured integer not null default 0,
			cache_creation_configured integer not null default 0,
			source text,
			source_model_id text,
			raw_json text,
			updated_at_ms integer not null,
			synced_at_ms integer
		);
INSERT INTO "model_prices" (rowid,"model","prompt_per_1m","completion_per_1m","cache_per_1m","cache_read_per_1m","cache_creation_per_1m","prompt_configured","completion_configured","cache_read_configured","cache_creation_configured","source","source_model_id","raw_json","updated_at_ms","synced_at_ms") VALUES(1,'claude-opus-5-5',4.0,20.0,0.0,0.4,5.0,1,1,1,1,'synthetic fixture',NULL,NULL,1790726400000,NULL);
CREATE TABLE settings (
			key text primary key,
			value text not null,
			updated_at_ms integer not null
		);
INSERT INTO "settings" (rowid,"key","value","updated_at_ms") VALUES(1,'usage_monitoring_model_format_version','1',1791421381716);
INSERT INTO "settings" (rowid,"key","value","updated_at_ms") VALUES(2,'usage_account_history_identity_format_version','identity-3:model-1',1791421381718);
INSERT INTO "settings" (rowid,"key","value","updated_at_ms") VALUES(3,'usage_dashboard_hourly_format_version','3',1791421381718);
CREATE TABLE usage_event_identity_ledger (
			event_hash text primary key,
			raw_event_id integer,
			timestamp_ms integer not null,
			bucket_ms integer not null,
			aggregate_schema_version integer not null default 0,
			aggregate_structure_revision text not null default '',
			first_seen_at_ms integer not null,
			updated_at_ms integer not null
		);
CREATE TABLE usage_events (
			id integer primary key autoincrement,
			request_id text,
			event_hash text not null unique,
			timestamp_ms integer not null,
			timestamp text not null,
			provider text,
			executor_type text,
			model text not null,
			endpoint text,
			method text,
			path text,
			client_ip text,
			x_forwarded_for text,
			user_agent text,
			auth_type text,
			auth_index text,
			source text,
			source_hash text,
			api_key_hash text,
			account_snapshot text,
			auth_label_snapshot text,
			auth_file_snapshot text,
			auth_provider_snapshot text,
			auth_account_id_snapshot text,
			auth_project_id_snapshot text,
			auth_snapshot_at_ms integer,
			requested_model text,
			resolved_model text,
			reasoning_effort text,
			service_tier text,
			request_service_tier text,
			response_service_tier text,
			cache_input_mode text,
			input_tokens integer not null default 0,
			output_tokens integer not null default 0,
			reasoning_tokens integer not null default 0,
			cached_tokens integer not null default 0,
			cache_tokens integer not null default 0,
			cache_read_tokens integer not null default 0,
			cache_creation_tokens integer not null default 0,
			normalized_uncached_input_tokens integer,
			normalized_total_input_tokens integer,
			normalized_cache_read_tokens integer,
			normalized_cache_creation_tokens integer,
			total_tokens integer not null default 0,
			latency_ms integer,
			ttft_ms integer,
			failed integer not null default 0,
			fail_status_code integer,
			fail_summary text,
			response_metadata_json text,
			header_quota_recover_at_ms integer,
			header_quota_used_percent real,
			header_quota_plan_type text,
			header_error_kind text,
			header_error_code text,
			header_trace_id text,
			fail_body text,
			raw_json text,
			created_at_ms integer not null
		);
